/**************************************************************************************************/
/* Copyright (C) Software Design, SSE@USTC, 2014-2015                                             */
/*                                                                                                */
/*  FILE NAME             :  linklist.c                                                           */
/*  PRINCIPAL AUTHOR      :  Zhugexubin                                                           */
/*  SUBSYSTEM NAME        :  linklist                                                             */
/*  MODULE NAME           :  linklist                                                             */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/19                                                           */
/*  DESCRIPTION           :  This is interface of linklist                                        */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Zhugexubin,2014/09/19
 *
 */

#ifndef _LINKLIST_H_
#define _LINKLIST_H_

#include <pthread.h>

#define SUCCESS 1
#define FAILURE 0

/*
 * LinkList Node Type
 */
typedef struct LinkListNode
{
    struct LinkListNode * pNext;
}tLinkListNode;

/*
 * LinkList Type
 */
typedef struct LinkList tLinkList;

/*
 * Create a LinkList
 */
tLinkList * CreateLinkList();
/*
 * Delete a LinkList
 */
int DeleteLinkList(tLinkList *pLinkList);
/*
 * Add a LinkListNode to LinkList
 */
int AddLinkListNode(tLinkList *pLinkList,tLinkListNode * pNode);
/*
 * Delete a LinkListNode from LinkList
 */
int DelLinkListNode(tLinkList *pLinkList,tLinkListNode * pNode);
/*
 * Search a LinkListNode from LinkList
 * int Conditon(tLinkListNode * pNode);
 */
tLinkListNode * SearchLinkListNode(tLinkList *pLinkList, int Conditon(tLinkListNode * pNode));
/*
 * get LinkListHead
 */
tLinkListNode * GetLinkListHead(tLinkList *pLinkList);
/*
 * get next LinkListNode
 */
tLinkListNode * GetNextLinkListNode(tLinkList *pLinkList,tLinkListNode * pNode);

#endif /* _LINKLIST_H_ */



