/**************************************************************************************************/
/* Copyright (C) Software Design, SSE@USTC, 2014-2015                                             */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  Zhugexubin                                                           */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/19                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Zhugexubin, 2014/09/19
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include "menu.h"


tLinkList * head = NULL; //menu head 

/* data struct */
struct MenuNode
{
    tLinkListNode * pNext;
    char*   cmd;
    char*   desc;
    int     (*handler)();
};

int InitEmptyMenu()
{
    head = CreateLinkList();
 
    return 1; 
}


int InitMenu()
{
    head = CreateLinkList();
    tMenuNode* pNode = (tMenuNode*)malloc(sizeof(tMenuNode));
    pNode->cmd = "help";
    pNode->desc = "Menu List:";
    pNode->handler = Help;
    AddLinkListNode(head,(tLinkListNode *)pNode);
    pNode = (tMenuNode*)malloc(sizeof(tMenuNode));
    pNode->cmd = "version";
    pNode->desc = "Menu Program V1.0";
    pNode->handler = NULL; 
    AddLinkListNode(head,(tLinkListNode *)pNode);
    pNode = (tMenuNode*)malloc(sizeof(tMenuNode));
    pNode->cmd = "quit";
    pNode->desc = "Quit from Menu Program V1.0";
    pNode->handler = Quit; 
    AddLinkListNode(head,(tLinkListNode *)pNode);
 
    return 1; 
}
/* execute the constructed menu */
int ExecuteMenu()
{
    while(1)
    {
        char cmd[CMD_MAX_LEN];
        printf("Input a cmd > ");
        scanf("%s", cmd);
        tMenuNode *p = SearchCmd(cmd);
        if( p == NULL)
        {
            printf("This is a wrong cmd!\n ");
            continue;
        }
        printf("%s - %s\n", p->cmd, p->desc); 
        if(p->handler != NULL) 
        { 
            p->handler();
        }
    }
}

/* find a cmd in the linklist and return the MenuNode pointer */
tMenuNode* SearchCmd(char *cmd)
{
    tMenuNode *pNode = (tMenuNode*)GetLinkListHead(head);
    while(pNode != NULL)
    {
        if(!strcmp(pNode->cmd, cmd))
        {
            return  pNode;  
        }
        pNode = (tMenuNode*)GetNextLinkListNode(head,(tLinkListNode *)pNode);
    }
    return NULL;
}

/* show all cmd in Menulist */
int ShowAllCmd()
{
    tMenuNode *pNode = (tMenuNode*)GetLinkListHead(head);
    while(pNode != NULL)
    {
        printf("\t%s - %s\n", pNode->cmd, pNode->desc);
        pNode = (tMenuNode*)GetNextLinkListNode(head,(tLinkListNode *)pNode);
    }
    return 0;
}

/* show distinct cmd in Menulist */
int ShowDistinctCmd(char *cmd)
{
    tMenuNode *pMenuNode = SearchCmd(cmd);
    if(pMenuNode != NULL)
    {
        printf("%s - %s\n", pMenuNode->cmd, pMenuNode->desc);
        return SUCCESS;
    }
    printf("No such command on the menu list!\n");
    return FAILURE;
}

/* Insert a command to menu */
int InsertCmd(char* cmd, char* desc, int (*handler)())
{
    if(SearchCmd(cmd) != NULL)
    {
        printf("Command already exists in menu! Do you want to update it? (y/n)\n");
        char y_n = getchar();
        if(y_n == 'y')
        {
            UpdateCmd(cmd, desc, handler);
        }
        else if(y_n == 'n')
        {
            printf("Command not updated.\n");
        }
        return FAILURE;
    }
    tMenuNode *pNode = (tMenuNode*)malloc(sizeof(tMenuNode));
    pNode->cmd = cmd;
    pNode->desc = desc;
    pNode->handler = handler ; 
    AddLinkListNode(head, (tLinkListNode *)pNode);
    printf("Command inserted.\n");
    return SUCCESS;
}

int DelCmd(char* cmd)
{
    tMenuNode *pNode = SearchCmd(cmd);
    if(pNode == NULL)
    {
        printf("Delete failed, command not in the menu list!\n");
        return FAILURE;
    }
    DelLinkListNode(head, (tLinkListNode *)pNode);
    printf("Command deleted.\n");
    return SUCCESS;
}

int UpdateCmd(char* cmd, char* desc, int (*handler)())
{
    tMenuNode *pNode = SearchCmd(cmd);
    if(pNode == NULL)
    {
        printf("Command not in the menu list!\n");
        return FAILURE;
    }
    pNode->cmd = cmd;
    pNode->desc = desc;
    pNode->handler = handler; 
    printf("Command updated.\n");
    return SUCCESS;
}



