/**************************************************************************************************/
/* Copyright (C) Software Design, SSE@USTC, 2014-2015                                             */
/*                                                                                                */
/*  FILE NAME             :  testmenu.h                                                           */
/*  PRINCIPAL AUTHOR      :  Zhugexubin                                                           */
/*  SUBSYSTEM NAME        :  testmenu                                                             */
/*  MODULE NAME           :  testmenu                                                             */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/19                                                           */
/*  DESCRIPTION           :  This is an testmenu program for testing the universal menu           */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Zhugexubin,2014/09/19
 *
 */

#include <stdio.h>
#include "menu.h"

void ShowOperations()
{
    printf("***********************************************\n");
    printf("* Menu operation:\n");
    printf("*\t1.Initiate a menu with basic operations\n");
    printf("*\t2.Initiate a empty menu\n");
    printf("*\t3.Show all commands of the menu\n");
    printf("*\t4.Show distinct command of the menu\n");
    printf("*\t5.Insert a command to the menu\n");
    printf("*\t6.Delete a command from the menu\n");
    printf("*\t7.Search a command on the menu\n");
    printf("*\t8.Update a command of the menu\n");
    printf("*\t9.Execute the menu\n");
    printf("***********************************************\n");
}

int main()
{
    int cmdNo;
    char cmd[CMD_MAX_LEN];
    ShowOperations();
    while(1)
    {
        printf("Please to choose one menu operation number: ");
        scanf("%d", &cmdNo);
        switch(cmdNo)
        {    
            case 1: 
            {
                InitMenu();
                break;
            }
            case 2: 
            {
                InitEmptyMenu();
                break;
            }
            case 3: 
            {
                ShowAllCmd();
                break;
            }
            case 4: 
            {
                printf("Input the distinct command > ");
                scanf("%s", cmd);
                ShowDistinctCmd(cmd);    
                break;
            }
            case 5: 
            {
                InsertCmd("ps", "This is ps command!", NULL);        
                break;
            }
            case 6: 
            {
                printf("Input the deleting command > ");
                scanf("%s", cmd);
                DelCmd(cmd);
                ShowAllCmd();
                break;
            }
            case 7: 
            {
                printf("Input finding command > ");
                scanf("%s", cmd);
                if(SearchCmd(cmd) != NULL)
                {
                    printf("Command Searched.\n");
                }
                else
                {
                    printf("Command not Searched.\n");
                }
                break;
            }
            case 8: 
            {
                UpdateCmd("ps", "This is ps command!", NULL);
                break;
            }
            case 9: 
            {
                ExecuteMenu();
                break;
            }
            default:
            {
                break;
            }    
        }
    }
    return 0;
}

