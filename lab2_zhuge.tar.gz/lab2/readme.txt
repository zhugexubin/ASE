This is a testmenu program!

Build Procedure
    $ gcc handler.c linklist.c menu.c testmenu.c -o testmenu
    $ ./testmenu  

or  $ makefile
    $./testmenu

!!!---Remember that: Before using the menu, you are required to initiate it first.---!!!
!!!---In this program, you should choose 1 or 2 first                             ---!!!
