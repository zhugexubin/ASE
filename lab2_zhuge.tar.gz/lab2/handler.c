/**************************************************************************************************/
/* Copyright (C) Software Design, SSE@USTC, 2014-2015                                             */
/*                                                                                                */
/*  FILE NAME             :  handler.c                                                            */
/*  PRINCIPAL AUTHOR      :  Zhugexubin                                                           */
/*  SUBSYSTEM NAME        :  handler                                                              */
/*  MODULE NAME           :  handler                                                              */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/19                                                           */
/*  DESCRIPTION           :  This is for universal handler                                        */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Zhugexubin,2014/09/19
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include "handler.h"

int Help()
{
    ShowAllCmd();
    return 0; 
}

int Quit()
{
    exit(0);
}

