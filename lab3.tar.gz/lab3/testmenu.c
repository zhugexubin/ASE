#include <stdio.h>
#include "menu.h"

#define debug printf
#define TESTSIZE 16

int results[TESTSIZE] = { 1 };
char * info[TESTSIZE] =
{
    "Test report",
    "TC1 InitMenu",
    "TC2 InitEmptyMenu",
    "TC3.1 SearchCmd",
    "TC3.2 SearchCmd",
    "TC4.1 ShowDistinctCmd",
    "TC4.2 ShowDistinctCmd",
    "TC5 ShowAllCmd",
    "TC6.1 InsertCmd",
    "TC6.2 InsertCmd",
    "TC7.1 DelCmd",
    "TC7.1 DelCmd",
    "TC8.2 UpdateCmd",
    "TC8.2 UpdateCmd",
    "TC9 ExecuteMenu"
};
int handler()
{
}

int main()
{
    /* test cases */
    int i;
    int ret = InitMenu();
    if(ret == FAILURE)
    {
        debug("TC1 fail\n");
        results[1] = 1;
    }
    ret = InitEmptyMenu();
    if(ret == FAILURE)
    {
        debug("TC2 fail\n");
        results[2] = 1;
    }

    char *cmd = NULL;
    tMenuNode *p = NULL;
    p = SearchCmd(cmd);
    if(p != NULL)
    {
        debug("TC3.1 Succ\n");
        results[3] = 1;
    }

    cmd = "help";
    p = NULL;
    p = SearchCmd(cmd);
    if(p != NULL)
    {
        debug("TC3.2 fail\n");
        results[4] = 0;
    }

    cmd = "";
    ret = ShowDistinctCmd(cmd);
    if(ret = SUCCESS)
    {
        debug("TC4.1 succ\n");
        results[5] = 0;
    }
    cmd = "help";
    ret = ShowDistinctCmd(cmd);
    if(ret = SUCCESS)
    {
        debug("TC4.2 succ\n");
        results[6] = 0;
    }
    
    ret = ShowAllCmd();
    if(ret = SUCCESS)
    {
        debug("TC5 succ\n");
        results[7] = 0;
    }

    char *des = NULL;
    ret = InsertCmd(cmd, des, NULL);
    if(ret == FAILURE)
    {
        debug("TC6.1 fail\n");
        results[8] = 1;
    }

    des = NULL;
    ret = InsertCmd(cmd, des, handler);
    if(ret == FAILURE)
    {
        debug("TC6.2 fail\n");
        results[9] = 1;
    }

    cmd = "";
    ret = DelCmd(cmd);
    if(ret == FAILURE)
    {
        debug("TC7.1 fail\n");
        results[10] = 1;
    }
    cmd = "help";
    ret = DelCmd(cmd);
    if(ret == FAILURE)
    {
        debug("TC7.2 fail\n");
        results[11] = 1;
    }

    cmd = "";
    ret = UpdateCmd(cmd, des, NULL);
    if(ret == FAILURE)
    {
        debug("TC8.1 fail\n");
        results[12] = 1;
    }
    cmd = "help";
    ret = UpdateCmd(cmd, des, handler);
    if(ret == FAILURE)
    {
        debug("TC8.2 fail\n");
        results[13] = 1;
    }
     
    ret = ExecuteMenu();
    if(ret == FAILURE)
    {
        debug("TC9 fail\n");
        results[14] = 1;
    }
    /* test report */
    printf("Test report\n");
    for(i = 1; i <= TESTSIZE; i++)
    {
        if(results[i] == 1)
        {
            printf("Testcase Number%d F - %s\n",i,info[i]);
        }
    }
}
