This is a testmenu program!

Build Procedure
    $ gcc linktable.c menu.c testmenu.c -o test
    $ ./test  

or  $ make
    $./test



