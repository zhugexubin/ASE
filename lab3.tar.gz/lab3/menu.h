/**************************************************************************************************/
/* Copyright (C) Software Design, SSE@USTC, 2014-2015                                             */
/*                                                                                                */
/*  FILE NAME             :  menu.h                                                               */
/*  PRINCIPAL AUTHOR      :  Zhugexubin                                                           */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/19                                                           */
/*  DESCRIPTION           :  This is an interface of menu program                                 */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Zhugexubin, 2014/09/19
 *
 */

#ifndef _MENU_H_
#define _MENU_H_

#include "linktable.h"
#define SUCCESS 0
#define FAILURE (-1)

#define CMD_MAX_LEN 128

/* MenuNode Declaration */
typedef struct MenuNode tMenuNode;

/* Initiate a empty menu */
int InitEmptyMenu();

/* Initiate a menu with useful internal cmd */
int InitMenu();

/* Search a cmd by cmd name */
tMenuNode* SearchCmd(char *cmd);

/* Show all the cmds of the menu */
int ShowAllCmd();

/* Show distinct cmd by cmd name */
int ShowDistinctCmd(char *cmd);
 
/* Insert a cmd */
int InsertCmd(char* cmd, char* desc, int (*handler)());

/* Delete a cmd by cmd name*/
int DelCmd(char* cmd);

/* Udpate a cmd by cmd name*/
int UpdateCmd(char* cmd, char* desc, int (*handler)());

/* Execute the menu */
int ExecuteMenu();

#endif
