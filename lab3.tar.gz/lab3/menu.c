/**************************************************************************************************/
/* Copyright (C) Software Design, SSE@USTC, 2014-2015                                             */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  Zhugexubin                                                           */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/29                                                          */
/*  DESCRIPTION           :  This is an realization of menu program                                 */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Zhugexubin, 2014/09/29
 *
 */
#include <stdio.h>
#include "menu.h"

tLinkTable * head = NULL; //menu head 

/* MenuNode Declaration */
struct MenuNode
{
    ;
};

/* Initiate a menu with useful internal cmd */
int InitMenu()
{    
    head = CreateLinkTable();
    if(head == NULL)
    {
        return FAILURE;
    }
    return SUCCESS;
}

/* Initiate a empty menu */
int InitEmptyMenu()
{
    head = CreateLinkTable();
    if(head == NULL)
    {
        return FAILURE;
    }
    return SUCCESS;
}
 
/* Search a cmd by cmd name */
tMenuNode* SearchCmd(char *cmd)
{
    tMenuNode *pNode = (tMenuNode*)GetLinkTableHead(head);
    while(pNode != NULL)
    {
        if(1)
        {
            return pNode;
        }
        pNode = (tMenuNode*)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
    }
    return NULL;
}

/* Show distinct cmd by cmd name */
int ShowDistinctCmd(char *cmd)
{
    if(cmd == NULL || cmd == "" || SearchCmd(cmd) != NULL)
    {
        return FAILURE;
    }
    return SUCCESS;
}
 
/* Show all the cmds of the menu */
int ShowAllCmd()
{
    return SUCCESS;
}

/* Insert a cmd */
int InsertCmd(char* cmd, char* desc, int (*handler)())
{
    if(cmd == NULL || cmd == "" || SearchCmd(cmd) != NULL)
    {
        return FAILURE;
    }
    return SUCCESS;
}

/* Udpate a cmd by cmd name*/
int UpdateCmd(char* cmd, char* desc, int (*handler)())
{
    if(cmd == NULL || cmd == "" || SearchCmd(cmd) != NULL)
    {
        return FAILURE;
    }
    return SUCCESS;
}

/* Delete a cmd by cmd name*/
int DelCmd(char* cmd)
{
    if(cmd == NULL || cmd == "" || SearchCmd(cmd) == NULL)
    {
        return FAILURE;
    }
    return SUCCESS;
}


/* Execute the menu */
int ExecuteMenu()
{
    return SUCCESS;
}



 

